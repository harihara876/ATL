export const questionTypes= {
    "0": "question_choice_level_1",
    "1": "question_choice_level_2",
    "2": "question_choice_level_3",
    "3": "question_choice_level_4",
    "4": "question_fill_blank_level_1",
    "5": "question_fill_blank_level_2",
    "6": "question_fill_blank_level_3",
    "7": "question_fill_blank_level_4",
    "8": "question_passage_level_1",
    "9": "question_passage_level_2",
    "10": "question_passage_level_3",
    "11": "question_passage_level_4"
  }