export const questionBankCollections = [
    "question_choice_level_1",
    "question_choice_level_2",
    "question_choice_level_3",
    "question_choice_level_4",
    "question_fill_blank_level_1",
    "question_fill_blank_level_2",
    "question_fill_blank_level_3",
    "question_fill_blank_level_4",
    "question_passage_level_1",
    "question_passage_level_2",
    "question_passage_level_3",
    "question_passage_level_4",
]