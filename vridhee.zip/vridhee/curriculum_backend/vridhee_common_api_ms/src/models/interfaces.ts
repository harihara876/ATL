export interface IS3BucketKey {
    "key": string
}