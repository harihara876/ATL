// import { ParsedQs } from 'qs';

// export interface IDefaultQuery {
//     "courseSection":string
// };

// export interface IConfigQuery extends ParsedQs{
//     "flag":string,
//     "id":string
// };

// export interface ICampusQuery {
//     "section":string
// };

// export interface IGroupQuery {
//     "id":string,
//     "groupCategory":string
// };

// export interface IModuleQuery {
//     "moduleSection":string
// };

// export interface ICountryQuery {
//     "country_id":string,
//     "state_id":string,
//     "district_id":string
// };