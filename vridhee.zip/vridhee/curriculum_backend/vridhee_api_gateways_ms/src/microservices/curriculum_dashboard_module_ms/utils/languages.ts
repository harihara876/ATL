export const languages= {
    "1": "vridheeCurriculumEnglish",
    "6": "vridheeCurriculumHindi"
  }