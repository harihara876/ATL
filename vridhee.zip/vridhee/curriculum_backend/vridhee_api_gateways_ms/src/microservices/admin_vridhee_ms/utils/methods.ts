export const methods = ["videoContentLevel1", "bookEContentLevel1", "aiEContentLevel1", "aiEContentLevel2", "aiEContentLevel3", "aiEContentLevel4",
  "teacherEContentLevel1", "examplesLevel1", "importantPointsLevel1", "excerciseLevel1", "questionChoiceLevel1",
  "questionChoiceLevel2", "questionChoiceLevel3", "questionChoiceLevel4", "questionFillBlankLevel1", "questionFillBlankLevel2",
  "questionFillBlankLevel3", "questionFillBlankLevel4", "questionPassageLevel1", "questionPassageLevel2", "questionPassageLevel3",
  "questionPassageLevel4", "getbookEContentLevel1", "getQuestionChoiceLevel1", "getQuestionChoiceLevel2",
  "getQuestionChoiceLevel3", "getQuestionChoiceLevel4", "getQuestionFillBankLevel1", "getQuestionFillBankLevel2",
  "getQuestionFillBankLevel3", "getQuestionFillBankLevel4", "getQuestionPassageLevel1", "getQuestionPassageLevel2",
  "getQuestionPassageLevel3", "getQuestionPassageLevel4", "getTeacherEContentLevel1", "getAiEContentLevel1",
  "getAiEContentLevel2", "getAiEContentLevel3", "getAiEContentLevel4", "getVideoContentLevel1", "getQuestions", 
  "getExampleLevel", "getImportantPointsLevel", "getExerciseLevel", "createVideoTLine", "updateVideoTLine",
  "deleteVideoTLine", "getVideoAndTL","aiEContentsData","getQuestions"
];