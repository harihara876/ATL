export const languages = {
  "1": "vridheeCurriculumEnglish",
  "3": "vridheeCurriculumHindi",
  "all": "vridheeCurriculumAll"
}