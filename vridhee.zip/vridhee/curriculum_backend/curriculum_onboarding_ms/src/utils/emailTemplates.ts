export const  emailVerificationMessage = 'is the OTP to verify your account.';
export const forgetOTPVerification = 'is the OTP to change your password';