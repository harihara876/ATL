export default function Lang(){
    return(
        <div></div>
    );
}