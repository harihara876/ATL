import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
import CssBaseline from '@mui/material/CssBaseline';
import Typography from '@mui/material/Typography';
import { Link, useNavigate } from 'react-router-dom';
import Breadcrumbs from '@mui/material/Breadcrumbs';
const drawerWidth = 300;

export default function Lang(){
    
    return(
        <div>
             <Box sx={{ display: 'flex' }}>
             <CssBaseline />
             <Drawer
                sx={{
                    width: drawerWidth,
                    flexShrink: 0,
                    '& .MuiDrawer-paper': {
                        width: drawerWidth,
                        boxSizing: 'border-box',
                    },
                }}
                variant="permanent"
                anchor="left"  >
                <div className="sidebar-sec">
                <div className="sidebar-logo">
                    <img src="" alt="" />
                </div>
                <div className="sidebar-menu">
                    <ul>
                        <li><a className="" href="./personal-information"><img src="assets/img/onboarding/Personal_info_Icon.png" alt="" />Personal Information</a></li>
                        <li><a className="" href="./learning-interest"><img src="assets/img/onboarding/Learning_Int_dark.png" alt="" />Learning Interest</a></li>
                        <li><a className="" href="./hobbies-passion"><img src="assets/img/onboarding/Hobbies_and_passion_Icon.png" alt="" />Hobbies &amp; Passion</a></li>
                        <li><a className="" href="./skills-interests"><img src="assets/img/onboarding/Skills_and_Int_Icon.png" alt="" />Skills &amp; Interests</a></li>
                        <li><a className="" href="./educational-details"><img src="assets/img/onboarding/Education_detail_Icon.png" alt="" />Educational details</a></li>
                        <li><a className="" href="./professional-details"><img src="assets/img/onboarding/Professional_details_Icon.png" alt="" />Professional details</a></li>
                        <li><a className="" href="./awards-certificates"><img src="assets/img/onboarding/Awards_and_certificate_Icon.png" alt="" />Awards &amp; Certificates</a></li>
                        <li><a className="" href="./network"><img src="assets/img/onboarding/Network_Icon.png" alt="" />Network</a></li>
                        </ul>
                </div>  
                </div>
            </Drawer>
            <Box
                component="main"
                sx={{ flexGrow: 1, bgcolor: 'background.default', p: 3 }}  >
                

                </Box>
             </Box>
        </div>
    );
}