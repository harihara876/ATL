import React from "react";
export default function Education(){
    return (
        <div>

        </div>
    )
}